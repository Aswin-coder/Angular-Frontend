# Bootstrap

The services in this folder should be singletons and used for sharing data and functionality.

# Interceptors

https://angular.io/guide/http#intercepting-requests-and-responses

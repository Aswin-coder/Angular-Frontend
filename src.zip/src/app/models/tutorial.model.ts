export class Tutorial {
  eid?: any;
  name?: string;
  rfid?: number;
  test?: string;
  time?: string;
  date?: string;
  temp?: number;
  id?: any;
  email?: string;
  password?: string;
  admin?: string;
  clogin?:boolean;
  cname?:string;
  cadmin?:boolean;
  rid?:string;
  rname?:string;
  redit?: string;
  radd?: string;
  rdelete?: string;
}

export class Current {
  clogin?:boolean;
  cname?:string;
  cadmin?:boolean;
}

export class Tutorialtest {
  a?:string;
  b?:string;
  c?:string;
  d?:string;
}

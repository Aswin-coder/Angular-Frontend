export class EmployeeModel{
    eid : number=0;
    name : string='';
    email : string='';
    password : string='';
    mobile : string='';
    salary : string='';
    admin : string='';
    a : string='';
    b : string='';
    c : string='';
    d : string='';
  imgname : string='';
}

export class CurrentUser{
    clogin : boolean=false;
    cname : string='';
    cadmin : boolean=false;

}

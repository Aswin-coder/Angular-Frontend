export const environment = {
  production: true,
  baseUrl: '',
  useHash: false,
};

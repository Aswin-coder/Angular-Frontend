export class Tutorial {
  eid?: any;
  name?: string;
  rfid?: number;
  test?: string;
  time?: string;
  date?: string;
  temp?: number;
  id?: any;
  email?: string;
  password?: string;
  admin?: string;
  clogin?:boolean;
  cname?:string;
  cadmin?:boolean;
}

export class Current {
  clogin?:boolean;
  cname?:string;
  cadmin?:boolean;
}
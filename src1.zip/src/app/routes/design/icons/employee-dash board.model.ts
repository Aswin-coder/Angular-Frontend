export class EmployeeModel{
    eid : number=0;
    name : string='';
    email : string='';
    password : string='';
    mobile : string='';
    salary : string='';
    admin : string='';
    
}

export class CurrentUser{
    clogin : boolean=false;
    cname : string='';
    cadmin : boolean=false;
    
}